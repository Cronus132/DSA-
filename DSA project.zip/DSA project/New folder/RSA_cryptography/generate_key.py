import random
from math import gcd

def generate_keypair(bits):
    # Step 1: Generate two large prime numbers, p and q
    p = generate_large_prime(bits)
    q = generate_large_prime(bits)

    # Step 2: Compute n (the modulus)
    n = p * q

    # Step 3: Compute the totient of n
    phi = (p - 1) * (q - 1)

    # Step 4: Choose e (public exponent) such that 1 < e < phi and gcd(e, phi) = 1
    e = choose_public_exponent(phi)

    # Step 5: Compute d (private exponent) such that (d * e) % phi == 1
    d = modular_inverse(e, phi)

    # Public key is (n, e), Private key is (n, d)
    return ((n, e), (n, d))

def generate_large_prime(bits):
    # Generate a large prime number with 'bits' bits
    while True:
        candidate = random.getrandbits(bits)
        if is_prime(candidate):
            return candidate

def is_prime(n, k=5):
    # Miller-Rabin primality test
    if n == 2 or n == 3:
        return True
    if n % 2 == 0:
        return False

    r, s = 0, n - 1
    while s % 2 == 0:
        r += 1
        s //= 2

    for _ in range(k):
        a = random.randint(2, n - 1)
        x = pow(a, s, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

def choose_public_exponent(phi):
    # Choose a public exponent 'e' such that 1 < e < phi and gcd(e, phi) == 1
    e = random.randint(2, phi - 1)
    while gcd(e, phi) != 1:
        e = random.randint(2, phi - 1)
    return e

def modular_inverse(a, m):
    # Compute the modular multiplicative inverse using extended Euclidean algorithm
    m0, x0, x1 = m, 0, 1
    while a > 1:
        q = a // m
        m, a = a % m, m
        x0, x1 = x1 - q * x0, x0
    return x1 + m0 if x1 < 0 else x1

# Example usage
bits = 1024
public_key, private_key = generate_keypair(bits)
for key in public_key:
    print(key)
for key in private_key:
    print(key)