import socket

# Server configuration
server_ip = '192.168.100.71'  # Replace with the actual IP address of the server
server_port = 12345

# Create a socket object
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect((server_ip, server_port))
print(f"Connected to {server_ip}:{server_port}")

# Send data to the server
data_to_send = "Hello, server!"
client_socket.send(data_to_send.encode('utf-8'))

# Close the connection
client_socket.close()
