import  sqlite3
def fetch_data():
    # Create a new connection to the database
    with sqlite3.connect("userdata.db") as conn:
        current = conn.cursor()

        # Retrieve all data from the 'userdata' table
        current.execute("SELECT * FROM userdata")
        rows = current.fetchall()

        # Print the retrieved data
        for row in rows:
            print(row)
fetch_data()