import socket

# Create a client socket
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server (assuming the server is running on localhost and port 9999)
client.connect(("localhost", 3333))



print("if you hace no account press 1 to create account or sinup")
print("if you have account press 2 to login")
print("if you want to delete your account press 3")
choice = int(input("Enter your choice "))
if choice == 1:
    client.send("signup".encode())
    message = client.recv(1024).decode()
    client.send(input(message).encode())
    message = client.recv(1024).decode()
    client.send(input(message).encode())
    print(client.recv(1024).decode())

elif choice == 2:
    client.send("login".encode())
    message = client.recv(1024).decode()
    client.send(input(message).encode())
    message = client.recv(1024).decode()
    client.send(input(message).encode())
    print(client.recv(1024).decode())
elif choice == 3:
    client.send("del".encode())

    message = client.recv(1024).decode()
    client.send(input(message).encode())
    print(client.recv(1024).decode())