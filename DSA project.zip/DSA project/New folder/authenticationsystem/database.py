import sqlite3
import hashlib

conn = sqlite3.connect("userdata.db")
current = conn.cursor()
current.execute(
    """
    CREATE TABLE IF NOT EXISTS userdata(
    id INTEGER PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(64) NOT NULL
    )
    """
)

username1 = "zeeahmad0505@gmail.com"
password1 = hashlib.sha256("Zee_cyber".encode()).hexdigest()

username2 = "1234"
password2 = hashlib.sha256("1234".encode()).hexdigest()

current.execute("INSERT INTO userdata (username, password) VALUES (?, ?)", (username1, password1))
current.execute("INSERT INTO userdata (username, password) VALUES (?, ?)", (username2, password2))

conn.commit()

conn.close()
