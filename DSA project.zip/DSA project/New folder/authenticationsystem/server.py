import sqlite3
import hashlib
import socket
import threading

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("localhost", 3333))
server.listen()


def handle_connection(c):
    conn = sqlite3.connect("userdata.db")
    current = conn.cursor()

    request_type = c.recv(1024).decode()

    if request_type == "signup":
        c.send("Sign up - Enter your username: ".encode())
        username = c.recv(1024).decode()

        c.send("Password: ".encode())
        password = c.recv(1024).decode()

        # Encode the password string to bytes before hashing
        password_hash = hashlib.sha256(password.encode()).hexdigest()

        current.execute("SELECT * FROM userdata WHERE username = ? AND password = ?", (username, password_hash))
        if current.fetchall():
            c.send("This account exit already.....".encode())
        else:
            # Insert the user data into the database
            current.execute("INSERT INTO userdata (username, password) VALUES (?, ?)", (username, password_hash))
            conn.commit()
            c.send("User registered successfully.".encode())



    elif request_type == "login":
        c.send("Login - Enter your username: ".encode())
        username = c.recv(1024).decode()

        c.send("password : ".encode())
        password = c.recv(1024).decode()

        # Encode the password string to bytes before hashing
        password = hashlib.sha256(password.encode()).hexdigest()


        current.execute("SELECT * FROM userdata WHERE username = ? AND password = ?", (username, password))

        if current.fetchall():
            c.send("Login successful.....".encode())
        else:
            c.send("Login failed.....".encode())
    elif request_type == "del":
        c.send("Enter your username: ".encode())
        username = c.recv(1024).decode()

        # Define the DELETE statement with a WHERE clause based on the username
        delete_query = "DELETE FROM userdata WHERE username = ?"

        try:
            # Execute the DELETE statement with the specified condition
            current.execute(delete_query, (username,))
            conn.commit()
            c.send(f"Deleted user with username: {username}".encode())
        except sqlite3.Error as e:
            c.send(f"Error deleting user: {e}".encode())






    conn.close()  # Close the database connection

while True:
    client, addr = server.accept()
    threading.Thread(target=handle_connection, args=(client,)).start()
