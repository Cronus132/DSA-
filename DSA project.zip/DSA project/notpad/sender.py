import socket
def connection():
    # Server configuration
    server_ip = '192.168.211.1'
    server_port = 12346
    # Create a socket object
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Bind the socket to a specific address and port
    server_socket.bind((server_ip, server_port))

    # Listen for incoming connections
    server_socket.listen(1)
    print(f"Server listening on {server_ip}:{server_port}")

    # Accept a connection from a client
    global client_socket
    client_socket, client_address = server_socket.accept()
    print(f"Connection from {client_address}")
# Function to continuously send data to the receiver
def send_data(data):
    try:
        client_socket.send(str(data).encode('utf-8'))
    except :
        print(f"Error sending data: ")
        exit(1)
