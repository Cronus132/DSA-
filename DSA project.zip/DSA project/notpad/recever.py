import socket
import threading
import dec
# Receiver configuration
receiver_ip = '192.168.211.1'
receiver_port = 12346
# Create a socket object
receiver_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Connect to the sende
receiver_socket.connect((receiver_ip, receiver_port))
print(f"Connected to {receiver_ip}:{receiver_port}")
# Function to continuously receive and process data
def receive_data():
    while True:
        try:
            received_data = receiver_socket.recv(1024).decode('utf-8')
            while not received_data:
                # Block until data is received
                received_data = receiver_socket.recv(1024).decode('utf-8')

            dec_text = dec.decrypt(int(received_data))
            for dec_word in dec_text:
                print(dec_word, end = '')
            # Process the received data as needed
        except :
            pass
# Start a separate thread for receiving data
receive_thread = threading.Thread(target=receive_data)
receive_thread.start()
