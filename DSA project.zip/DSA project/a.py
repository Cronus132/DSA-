import numpy as np

def find_determinant(matrix):
    try:
        det = np.linalg.det(matrix)
        return det
    except np.linalg.LinAlgError:
        return "The matrix is singular. Determinant cannot be calculated."

# Example 5x5 matrix
matrix_5x5 = np.array([
    [20,8,5,13,25],
    [19,20,5,18,9],
    [15,21,15,6,4],
    [9,19,3,15,22],
    [5,18,9,5,11]
])

# Call the function to find the determinant
determinant_result = find_determinant(matrix_5x5)

# Display the result
print(f"Determinant of the 5x5 matrix:\n{determinant_result%26}")
